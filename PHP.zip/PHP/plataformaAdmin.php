<?php require('./layout/head.php'); ?>
<>
    <?php require('./layout/header.php') ?>

    <div class="container">
        <div class="contenedor-plataformaAdmin-menu-php">

            <div class="plataformaAdmin-btn-menu-php">
                <a href="./articulo.php">Articulo</a>
            </div>
            <div class="plataformaAdmin-btn-menu-php">
                <a href="#">Usuarios</a>
            </div>
            <div class="plataformaAdmin-btn-menu-php">
                <a href="#">Empresa</a>
            </div>
            <div class="plataformaAdmin-btn-menu-php">
                <a href="#">Buscar</a>
            </div>
            <div class="plataformaAdmin-btn-menu-php">
                <a href="../index.html">Salir</a>
            </div>

        </div>
    </div>
</body>