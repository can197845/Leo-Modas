<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/Esttilo.css">
    <!-- _________________ Fuentes ____________________________ -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Gwendolyn:wght@400;700&display=swap" rel="stylesheet">

    <!-- _______________________ Iconos de Boostrap ________________________________-->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <title>Leo MODAS</title>
</head>

<body>
<!-- LLAMO A LA CABECERA ____________________________-->
<?php require('./layout/header.php') ?>

    <main class="contenedor-php">
        <div>
           <form action="ValoidadorLogin.php" method="post"  enctype="multipart/form-data" name="form"> 
                
                <div class="contenedor-input-php">
                    <label for="usuario">USUARIO</label><br>
                    <input type="email" name="usuario" id="usuario" require>
                </div>
            
                <div class="contenedor-input-php">
                    <label for="clave">PASSWORD</label><br>
                    <input type="password"  name ="clave" require>
                </div>
             
                <div>
                    <button type="sunmit" id="btn-Ingresar" class="btn-ingresar-php">Ingresar</button>
                </div>
          </form>
        </div>
    </main>
</body>

</html>