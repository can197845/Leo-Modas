<?php require('./layout/head.php') ?>
<body>
    <?php require('./layout/header.php') ?>

    <div class="container">
        <div class="contenedor-articulo-menu-php">

            <div class="articulo-btn-menu-php">
                <a href="#">Aalta de Articulo</a>
            </div>
            <div class="articulo-btn-menu-php">
                <a href="#">Eliminar Articulo</a>
            </div>
            <div class="articulo-btn-menu-php">
                <a href="#">Editar Articulo</a>
            </div>
            <div class="articulo-btn-menu-php">
                <a href="#">Buscar Articulo</a>
            </div>
            <div class="articulo-btn-menu-php">
                <a href="../index.html">Salir</a>
            </div>

        </div>
    </div>
</body>