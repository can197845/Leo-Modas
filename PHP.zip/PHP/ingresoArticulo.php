<?php require('./layout/head.php')?>
<body>
    <?php require('./layout/header.php')?>
    <div class="continer-fluid">
        <form action="" method="post" class="ingresoArticulo-form">

            <div>
                <label for="categoria">Categoria:</label>
                <select name="categoria" id="categoria">
                    
            </div>

        </form>
    </div>
    
</body>